export class Book {
    isbn: number;
    name: string;
    author: string;
}
